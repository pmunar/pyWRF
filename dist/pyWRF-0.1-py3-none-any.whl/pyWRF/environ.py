import os

WRF_DIR = os.environ.get('WRF_DIR', '')
WRF_DATA = os.environ.get('WRF_DATA', '')
WRF_WPS = os.environ.get('WRF_WPS', '')
WRF_WRFV3 = os.environ.get('WRF_WRFV3', '')
WRF_ARWpost = os.environ.get('WRF_ARWpost', '')
